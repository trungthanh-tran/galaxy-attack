<?php $__env->startSection('content'); ?>

    <section class="sigin">
        <!-- <img src="images/signup-bg.jpg" alt=""> -->
        <div class="container">
            <div class="signup-content">
                <form method="POST" action="/login" class="signup-form">
                    <?php echo csrf_field(); ?>
                    <h2 class="form-title">Login Here</h2>
                    <?php if($errors->any()): ?>
                        <div class="text-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-0"><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="Text" class="form-input" name="name" id="name" placeholder="Your username" value="<?php echo e(old('name')); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-input" name="password" id="password" placeholder="Password"/>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" id="submit" class="form-submit" value="Sign In"/>
                    </div>
                </form>
                <p class="loginhere">
                    <a href="/register" class="loginhere-link">Register new account</a>
                </p>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\game\laravel-auth-custom\resources\views/login.blade.php ENDPATH**/ ?>
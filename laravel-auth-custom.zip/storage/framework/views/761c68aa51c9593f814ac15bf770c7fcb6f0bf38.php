<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e(config('app.name', 'Galaxy Fight - Shoot for entertainment')); ?></title>
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/game.css')); ?>" rel="stylesheet">
    </head>
    <body class="bg-light">
    <!-- Fixed navbar -->

    <nav class="top-bar top navbar navbar-transparent">
        <div class="col-md-12">
            <div class="py-4">
                <?php if(Route::has('login')): ?>
                    <div class="top-right links">
                        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                            <?php if(auth()->guard()->check()): ?>
                                <a class="navbar-brand border border-white" href="/">Welcome <?php echo e(Auth::user()->name); ?></a>
                            <?php endif; ?>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                                <div class="navbar-nav align-items-center">
                                    <?php if(auth()->guard()->check()): ?>
                                        <a class="nav-item nav-link border border-white <?php if(Request::path() === '/'): ?> active <?php endif; ?>" href="<?php echo e(url('/')); ?>">Dashboard</a>
                                        <a class="nav-item">
                                            <form action="/logout"  onclick= "galaxy.clearStorage()" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" value="Logout" class="btn btn-outline-danger">
                                            </form>
                                        </a>
                                    <?php else: ?>
                                        <a class="nav-item nav-link <?php if(Request::path() === 'login'): ?> active <?php endif; ?>" href="<?php echo e(url('/login')); ?>">Login</a>
                                        <?php if(Route::has('register')): ?>
                                            <a class="nav-item nav-link <?php if(Request::path() === 'register'): ?> active <?php endif; ?>" href="<?php echo e(url('/register')); ?>">Register</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <?php if(auth()->guard()->check()): ?>
        <input type="hidden" id="userId" name="userId" value="<?php echo e(Auth::user()->id); ?>">
        <input type="hidden" id="userName" name="userName" value="<?php echo e(Auth::user()->name); ?>">
    <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH D:\www\game\laravel-auth-custom\resources\views/layouts/app.blade.php ENDPATH**/ ?>